from .plugin import LOD1CityModelPlugin

def classFactory(iface):
    return LOD1CityModelPlugin(iface)
