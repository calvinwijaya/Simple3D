from qgis.PyQt.QtCore import QThread, pyqtSignal, Qt, QSize
from qgis.PyQt.QtWidgets import (QFileDialog, QMessageBox, QVBoxLayout, QHBoxLayout, QLabel,
                                 QPushButton, QLineEdit, QTextEdit, QWidget, QComboBox, QInputDialog, QAction)
from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer
import subprocess
import os

class ProcessThread(QThread):
    output_signal = pyqtSignal(str)

    def __init__(self, building_layer, point_cloud_file, dsm_layer, dtm_layer, output_dir, epsg_code, main_script):
        super().__init__()
        self.building_layer = building_layer
        self.point_cloud_file = point_cloud_file
        self.dsm_layer = dsm_layer
        self.dtm_layer = dtm_layer
        self.epsg_code = epsg_code
        self.output_dir = output_dir
        self.main_script = main_script

    def run(self):
        # Convert epsg_code to string
        epsg_code_str = str(self.epsg_code)
        
        # Run the process and capture output
        command = ['python', self.main_script, '--building_outline', self.building_layer, '--epsg', epsg_code_str, '--output', self.output_dir]
        
        if self.point_cloud_file:
            command.extend(['--point_cloud', self.point_cloud_file])
        if self.dsm_layer and self.dtm_layer:
            command.extend(['--dsm', self.dsm_layer, '--dtm', self.dtm_layer])
        
        # Run the process and capture output
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
        
        # Capture stdout
        for line in process.stdout:
            self.output_signal.emit(line.strip())

        # Capture stderr (in case there are errors)
        for line in process.stderr:
            self.output_signal.emit(f"Error: {line.strip()}")

        process.wait()

class LOD1CityModelPlugin(QWidget):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # Set window size
        self.setMinimumSize(800, 800)
        self.setWindowTitle("Simple 3D")

        # Select Building Outline layer
        self.building_label = QLabel('Select Building Outline Layer:')
        self.building_layer = QComboBox(self)
        self.building_btn = QPushButton('Select Layer', self)
        self.building_btn.clicked.connect(self.select_building_layer)

        # Layout for Building Outline
        building_layout = QHBoxLayout()
        building_layout.addWidget(self.building_layer)
        building_layout.addWidget(self.building_btn)

        # Select Point Cloud File
        self.point_cloud_label = QLabel('Select Point Cloud File:')
        self.point_cloud_file = QLineEdit(self)
        self.point_cloud_file.setReadOnly(True)
        self.point_cloud_btn = QPushButton('Browse', self)
        self.point_cloud_btn.clicked.connect(self.select_point_cloud_file)

        # Layout for Point Cloud
        point_cloud_layout = QHBoxLayout()
        point_cloud_layout.addWidget(self.point_cloud_file)
        point_cloud_layout.addWidget(self.point_cloud_btn)

        # Select DSM layer
        self.dsm_label = QLabel('Select DSM Layer:')
        self.dsm_layer = QComboBox(self)
        self.dsm_btn = QPushButton('Select Layer', self)
        self.dsm_btn.clicked.connect(self.select_dsm_layer)

        # Layout for DSM
        dsm_layout = QHBoxLayout()
        dsm_layout.addWidget(self.dsm_layer)
        dsm_layout.addWidget(self.dsm_btn)

        # Select DSM layer
        self.dtm_label = QLabel('Select DTM Layer:')
        self.dtm_layer = QComboBox(self)
        self.dtm_btn = QPushButton('Select Layer', self)
        self.dtm_btn.clicked.connect(self.select_dtm_layer)

        # Layout for DTM
        dtm_layout = QHBoxLayout()
        dtm_layout.addWidget(self.dtm_layer)
        dtm_layout.addWidget(self.dtm_btn)

        # EPSG Code
        self.epsg_label = QLabel('EPSG Code:')
        self.epsg_code = QLineEdit(self)

        # Layout for EPSG Code
        epsg_layout = QHBoxLayout()
        epsg_layout.addWidget(self.epsg_label)
        epsg_layout.addWidget(self.epsg_code)

        # Output Directory
        self.output_label = QLabel('Select Output Directory:')
        self.output_path = QLineEdit(self)
        self.output_path.setReadOnly(True)
        self.output_btn = QPushButton('Browse', self)
        self.output_btn.clicked.connect(self.select_output_directory)

        # Layout for Output Directory
        output_layout = QHBoxLayout()
        output_layout.addWidget(self.output_path)
        output_layout.addWidget(self.output_btn)

        # Start button
        self.start_btn = QPushButton('Start', self)
        self.start_btn.clicked.connect(self.start_process)

        # **Replay button with an icon**
        self.replay_btn = QPushButton(self)
        icon = QIcon(QPixmap("C:/Users/LENOVO/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/LOD1_City_Model/ui/replay.png"))
        self.replay_btn.setIcon(icon)
        self.replay_btn.setIconSize(QSize(24, 24))  # Set a smaller size for the replay button
        self.replay_btn.setFixedSize(32, 32)  # Make button smaller
        self.replay_btn.clicked.connect(self.reset_parameters)  # Connect to reset function

        # Layout for Start and Replay buttons
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.start_btn)
        button_layout.addWidget(self.replay_btn)  # Place Replay button beside the Start button

        # Console Log
        self.log_console = QTextEdit(self)
        self.log_console.setReadOnly(True)

        # Add widgets to layout
        layout.addWidget(self.building_label)
        layout.addLayout(building_layout)
        layout.addWidget(self.point_cloud_label)
        layout.addLayout(point_cloud_layout)
        layout.addWidget(self.dsm_label)
        layout.addLayout(dsm_layout)
        layout.addWidget(self.dtm_label)
        layout.addLayout(dtm_layout)
        layout.addLayout(epsg_layout)
        layout.addWidget(self.output_label)
        layout.addLayout(output_layout)
        layout.addLayout(button_layout)
        layout.addWidget(self.log_console)

        # Watermark Layout
        watermark_layout = QHBoxLayout()
        watermark_logo = QLabel(self)
        watermark_logo.setPixmap(QPixmap("C:/Users/LENOVO/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/LOD1_City_Model/ui/ugm.png").scaled(40, 40))
        watermark_layout.addWidget(watermark_logo)
        watermark_text = QLabel("Department of Geodetic Engineering\nFaculty of Engineering Universitas Gadjah Mada")
        watermark_layout.addWidget(watermark_text)
        watermark_layout.addStretch(1)
        watermark_layout.setContentsMargins(0, 20, 0, 0)
        layout.addLayout(watermark_layout)
        self.setLayout(layout)

    def initGui(self):
        # Create an action to be added to the QGIS GUI
        icon = QIcon(QPixmap("C:/Users/LENOVO/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/LOD1_City_Model/ui/logo.png"))
        self.action = QAction(icon, "", self.iface.mainWindow())
        self.action.triggered.connect(self.show_plugin)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&LOD1 City Model", self.action)

    def unload(self):
        # Remove the action when the plugin is unloaded
        self.iface.removePluginMenu("&LOD1 City Model", self.action)
        self.iface.removeToolBarIcon(self.action)

    def show_plugin(self):
        self.show()

    def select_building_layer(self):
        self.populate_layer_combobox(self.building_layer, "Select Building Outline Layer")

    def select_point_cloud_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "Select Point Cloud File", "", "LAS Files (*.las);;All Files (*)")
        if file:
            self.point_cloud_file.setText(file)
            # Disable DSM/DTM selection if point cloud is selected
            self.dsm_layer.setEnabled(False)
            self.dtm_layer.setEnabled(False)
        else:
            # Re-enable DSM/DTM if no point cloud is selected
            self.dsm_layer.setEnabled(True)
            self.dtm_layer.setEnabled(True)
    
    def select_dsm_layer(self):
        self.populate_layer_combobox_raster(self.dsm_layer, "Select DSM Layer")
        if self.dsm_layer.currentText():
            # Disable point cloud selection if DSM/DTM are selected
            self.point_cloud_file.setEnabled(False)
        else:
            # Re-enable point cloud if no DSM/DTM is selected
            self.point_cloud_file.setEnabled(True)
    
    def select_dtm_layer(self):
        self.populate_layer_combobox_raster(self.dtm_layer, "Select DTM Layer")
        if self.dtm_layer.currentText():
            # Disable point cloud selection if DSM/DTM are selected
            self.point_cloud_file.setEnabled(False)
        else:
            # Re-enable point cloud if no DSM/DTM is selected
            self.point_cloud_file.setEnabled(True)

    def populate_layer_combobox(self, combobox, dialog_title):
        layers = QgsProject.instance().mapLayers().values()
        layer_names = [layer.name() for layer in layers if isinstance(layer, QgsVectorLayer)]

        if not layer_names:
            QMessageBox.warning(self, 'Error', 'No vector layers found.')
            return

        # Populate the combobox
        combobox.clear()
        combobox.addItems(layer_names)

        # Show a dialog to select the layer
        selected_layer_name, ok = QInputDialog.getItem(self, dialog_title, "Select a layer:", layer_names, 0, False)
        if ok and selected_layer_name:
            combobox.setCurrentText(selected_layer_name)

    def populate_layer_combobox_raster(self, combobox, dialog_title):
        layers = QgsProject.instance().mapLayers().values()
        layer_names = [layer.name() for layer in layers if isinstance(layer, QgsRasterLayer)]

        if not layer_names:
            QMessageBox.warning(self, 'Error', 'No Raster layers found.')
            return

        # Populate the combobox
        combobox.clear()
        combobox.addItems(layer_names)

        # Show a dialog to select the layer
        selected_layer_name, ok = QInputDialog.getItem(self, dialog_title, "Select a layer:", layer_names, 0, False)
        if ok and selected_layer_name:
            combobox.setCurrentText(selected_layer_name)

    def select_output_directory(self):
        output_dir = QFileDialog.getExistingDirectory(self, "Select Output Directory")
        if output_dir:
            self.output_path.setText(output_dir)

    def start_process(self):
        building_layer_name = self.building_layer.currentText()
        point_cloud_file = self.point_cloud_file.text()
        dsm_layer_name = self.dsm_layer.currentText()
        dtm_layer_name = self.dtm_layer.currentText()
        output_dir = self.output_path.text()
        epsg_code = self.epsg_code.text()

        try:
            epsg_code = int(epsg_code)
        except ValueError:
            QMessageBox.warning(self, 'Error', 'Invalid EPSG Code.')
            return

        # Validation logic: Ensure either Point Cloud OR DSM/DTM is selected, not both
        if point_cloud_file and (dsm_layer_name or dtm_layer_name):
            QMessageBox.warning(self, 'Error', 'Select either Point Cloud or DSM/DTM, but not both.')
            return
        elif not point_cloud_file and not (dsm_layer_name and dtm_layer_name):
            QMessageBox.warning(self, 'Error', 'You must select a Point Cloud file or both DSM and DTM layers.')
            return

        # Proceed with starting the process if the validation passes
        plugin_dir = os.path.dirname(__file__)
        main_script = os.path.join(plugin_dir, 'main.py')

        layers = QgsProject.instance().mapLayers()
        building_layer = next((layer for layer in layers.values() if layer.name() == building_layer_name), None)
        dsm_layer = next((layer for layer in layers.values() if layer.name() == dsm_layer_name), None)
        dtm_layer = next((layer for layer in layers.values() if layer.name() == dtm_layer_name), None)

        # Get the actual file path of the building, dsm, and dtm layer
        building_layer_path = self.get_layer_path(building_layer)
        dsm_layer_path = self.get_layer_path(dsm_layer) if dsm_layer else None
        dtm_layer_path = self.get_layer_path(dtm_layer) if dtm_layer else None

        # Start the process in a separate thread
        self.process_thread = ProcessThread(building_layer_path, point_cloud_file, dsm_layer_path, dtm_layer_path, output_dir, epsg_code, main_script)
        self.process_thread.output_signal.connect(self.update_console_log)
        self.process_thread.start()

    def get_layer_path(self, layer):
        """Retrieve the file path of the layer."""
        if layer.dataProvider().dataSourceUri().startswith("file://"):
            return layer.dataProvider().dataSourceUri()[7:]  # Remove 'file://'
        return layer.dataProvider().dataSourceUri()

    def update_console_log(self, message):
        self.log_console.append(message)

    def reset_parameters(self):
        """Reset all input fields and parameters."""
        # Reset the building layer selection
        self.building_layer.clear()

        # Reset the point cloud file path
        self.point_cloud_file.clear()

        # Reset the dsm layer selection
        self.dsm_layer.clear()

        # Reset the dtm layer selection
        self.dtm_layer.clear()

        # Reset the EPSG code
        self.epsg_code.clear()

        # Reset the output directory path
        self.output_path.clear()

        # Reset the log console
        self.log_console.clear()

        # Optionally, repopulate the layers in the combobox
        self.populate_layer_combobox(self.building_layer, "Select Building Outline Layer")
        self.populate_layer_combobox_raster(self.dsm_layer, "Select DSM Layer")
        self.populate_layer_combobox_raster(self.dtm_layer, "Select DTM Layer")
        
# Add this function to create the plugin instance
def classFactory(iface):
    return LOD1CityModelPlugin(iface)